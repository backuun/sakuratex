// gsap.registerPlugin(ScrollTrigger);

// gsap.to(".square", {
//     x: 1000,
//     duration: 10,
//     scrollTrigger: {
//         trigger: ".square",
//         start: "top 60%",
//         end: "top 10%",
//         scrub: true,
//         toggleActions: "restart none none none",
//         markers: {
//             startColor: "purple",
//             endColor: "fuchsia",
//             fontSize: "2rem",
//         },
//     }
// })

gsap.to(".logo-digi", {
    y: 100,
    duration: 2
})