var elem = document.getElementById("magazine");
    function openFullscreen() {
      if (elem.requestFullscreen) {
        elem.requestFullscreen();
      } else if (elem.webkitRequestFullscreen) { /* Safari */
        elem.webkitRequestFullscreen();
      } else if (elem.msRequestFullscreen) { /* IE11 */
        elem.msRequestFullscreen();
      }
    }
    function closeFullscreen() {
     if (document.exitFullscreen) {
        document.exitFullscreen();
     } else if (document.webkitExitFullscreen) { /* Safari */
        document.webkitExitFullscreen();
     } else if (document.msExitFullscreen) { /* IE11 */
        document.msExitFullscreen();
     }
    }

var elem2 = document.getElementById("magazine2");
    function openFullscreen2() {
      if (elem2.requestFullscreen) {
        elem2.requestFullscreen();
      } else if (elem2.webkitRequestFullscreen) { /* Safari */
        elem2.webkitRequestFullscreen();
      } else if (elem2.msRequestFullscreen) { /* IE11 */
        elem2.msRequestFullscreen();
      }
    }
    function closeFullscreen2() {
     if (document.exitFullscreen) {
        document.exitFullscreen();
     } else if (document.webkitExitFullscreen) { /* Safari */
        document.webkitExitFullscreen();
     } else if (document.msExitFullscreen) { /* IE11 */
        document.msExitFullscreen();
     }
    }

var elem3 = document.getElementById("magazine3");
    function openFullscreen3() {
      if (elem3.requestFullscreen) {
        elem3.requestFullscreen();
      } else if (elem3.webkitRequestFullscreen) { /* Safari */
        elem3.webkitRequestFullscreen();
      } else if (elem3.msRequestFullscreen) { /* IE11 */
        elem3.msRequestFullscreen();
      }
    }
    function closeFullscreen3() {
     if (document.exitFullscreen) {
        document.exitFullscreen();
     } else if (document.webkitExitFullscreen) { /* Safari */
        document.webkitExitFullscreen();
     } else if (document.msExitFullscreen) { /* IE11 */
        document.msExitFullscreen();
     }
    }

var elem4 = document.getElementById("magazine4");
    function openFullscreen4() {
      if (elem4.requestFullscreen) {
        elem4.requestFullscreen();
      } else if (elem4.webkitRequestFullscreen) { /* Safari */
        elem4.webkitRequestFullscreen();
      } else if (elem4.msRequestFullscreen) { /* IE11 */
        elem4.msRequestFullscreen();
      }
    }
    function closeFullscreen4() {
     if (document.exitFullscreen) {
        document.exitFullscreen();
     } else if (document.webkitExitFullscreen) { /* Safari */
        document.webkitExitFullscreen();
     } else if (document.msExitFullscreen) { /* IE11 */
        document.msExitFullscreen();
     }
    }

var elem5 = document.getElementById("magazine5");
    function openFullscreen5() {
      if (elem5.requestFullscreen) {
        elem5.requestFullscreen();
      } else if (elem5.webkitRequestFullscreen) { /* Safari */
        elem5.webkitRequestFullscreen();
      } else if (elem5.msRequestFullscreen) { /* IE11 */
        elem5.msRequestFullscreen();
      }
    }
    function closeFullscreen5() {
     if (document.exitFullscreen) {
        document.exitFullscreen();
     } else if (document.webkitExitFullscreen) { /* Safari */
        document.webkitExitFullscreen();
     } else if (document.msExitFullscreen) { /* IE11 */
        document.msExitFullscreen();
     }
    }

var elem6 = document.getElementById("magazine6");
    function openFullscreen6() {
      if (elem6.requestFullscreen) {
        elem6.requestFullscreen();
      } else if (elem6.webkitRequestFullscreen) { /* Safari */
        elem6.webkitRequestFullscreen();
      } else if (elem6.msRequestFullscreen) { /* IE11 */
        elem6.msRequestFullscreen();
      }
    }
    function closeFullscreen6() {
     if (document.exitFullscreen) {
        document.exitFullscreen();
     } else if (document.webkitExitFullscreen) { /* Safari */
        document.webkitExitFullscreen();
     } else if (document.msExitFullscreen) { /* IE11 */
        document.msExitFullscreen();
     }
    }