var loader = document.getElementById("loading");
window.addEventListener("load", function(){
    loader.style.display = "none";
})